package com.coforge.model;

import lombok.Data;

@Data
public class Employee {
 private int empId;
 private  String empName;

}
