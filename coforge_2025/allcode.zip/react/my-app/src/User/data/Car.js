export const cars=[

    {
        "card_id":9000001,
        "model":"maruti zen",
        "cost":1200000,
    },

    {
        "card_id":9000002,
        "model":"jaguar",
        "cost":1200000,
    },
    {
        "card_id":9000003,
        "model":"thar",
        "cost":2000000,
    },
    {
        "card_id":9000004,
        "model":"celario",
        "cost":700000,
    },



]