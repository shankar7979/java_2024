
public class HostellerMain {

}
