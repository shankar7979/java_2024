package exception;

public class ExceptionProgram1 {

	public static void main(String[] args) {
		
		int ar[]= {11,22,3,4,5,6};
		//System.out.println(ar[6]);
		
		
		int result=10/1;
		result=10/9;
		result=10/10;
		//result=10/0;
		
		System.out.println(10/0.0f);
		//System.out.println(10/0);
		
		Integer x1=100;
		Integer p=null;
		//System.out.println(p.intValue());
		
		String s1=null;
		System.out.println(s1.charAt(1));
	}
}
