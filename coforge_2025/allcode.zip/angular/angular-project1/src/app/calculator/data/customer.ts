export const data= [
     {
        "id":100001,
        "name":"amit kumar",
        "salary":88000
     },
     
     {
        "id":100002,
        "name":"sumit kumar",
        "salary":83000
     },
     {
        "id":100003,
        "name":"parvin kumar",
        "salary":67000
     },
     {
        "id":100004,
        "name":"rahul kumar",
        "salary":88000
     },
     {
        "id":100005,
        "name":"jayant kumar",
        "salary":67000
     }
]