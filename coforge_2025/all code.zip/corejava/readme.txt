
Create a class Circle with variable radius 

make two static function for area and circumference 

call and print area and circumference