public class Student {

	int roll;
	String name;
	String subject;
	
	void exam() {
		System.out.println("student exam");
	}
	
	
	
}
