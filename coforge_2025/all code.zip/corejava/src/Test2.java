import static java.lang.Math.PI;
import static java.lang.System.out;

import java.io.PrintStream;

public class Test2 {

	public static void main(String[] args) {
		
		// static import 
		
		
		//System.out.println(Math.PI);
//		System.out.println(Math.sin(Math.PI/2));
	
		System.out.println(PI);
		out.print("hello world");
		
		/*
		 *  System class is present in java.lang
		 *      inside java.lang.System 
		 *      public static final PrintStream out = null;

		 */
		
		
		
		
		
		
	}
	
}
