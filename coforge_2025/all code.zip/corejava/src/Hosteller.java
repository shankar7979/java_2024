
public class Hosteller {
	private String hostelName;
	private int roomNumber;

}
