package corejava;

public class VarTest2 {
	
	public static void main(String[] args) {
		
		var a=10;
		var name="ram kumar";
		var salary=20000.67f;
		
		var myname=new StringBuffer("delhi");

		
		
	}
}
