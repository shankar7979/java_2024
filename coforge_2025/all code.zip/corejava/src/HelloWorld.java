
public class HelloWorld {

	// main   -- ctrl+space 
	public static void main(String[] args) {
		System.out.println("hello world");
		//sysout  -- ctrl+space
		
		System.out.println("greeting to java");
		
	}
}
