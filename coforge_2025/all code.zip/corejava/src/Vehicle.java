public class Vehicle {

	protected int id;
	protected String model;
	protected float cost;

	public Vehicle() {
	}

	public int getId() {
		return id;
	}

	public String getModel() {
		return model;
	}

	public float getCost() {
		return cost;
	}

}
