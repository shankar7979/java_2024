
public class Test1 {

	public static void main(String[] args) {
		
		int x=10, y=20;
		int z=x+y;
//		System.out.println("first no is "+x);
//		System.out.println("second  no is "+y);
//		System.out.println("sum   is "+z);

		System.out.printf("no1 is %d \nno2 is %d\nsum is %d",x,y,z);
		
	}
}
