export class Employee {
    public id:number;
    public name: string;
    public dob: string;

    constructor() {
        this.id=0;
        this.name = ""
        this.dob = "";
    }
}
