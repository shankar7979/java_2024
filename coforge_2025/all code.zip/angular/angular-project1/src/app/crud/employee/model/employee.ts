export class Employee {
    public name: string;
    public dob: string;

    constructor() {
        this.name = ""
        this.dob = "";
    }
}
