package com.coforge;

public class Hello {
    void display(){
        System.out.println("hello world");
    }
}
