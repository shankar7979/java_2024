package com.coforge.model;

public interface Shape {
    float area();
}
