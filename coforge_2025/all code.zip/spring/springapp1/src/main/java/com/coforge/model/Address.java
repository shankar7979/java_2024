package com.coforge.model;

import lombok.Data;

@Data
public class Address {

    private int addr_id;
    private  String  location;
    private  String  city;



}
