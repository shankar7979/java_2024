to generate component 

    ng generate component  employee
    ng g c  employee

to start build and serve 
   ng serve

   two way binding 

      ng g c  calculator


      inside app create folder crud 
      rt. click on crud folder-->Open in integrated Terminal
      set path for node js
       
      ng g c Employee 

      inside employee create folder model
      cd employee\model
         either create a file employee.ts inside model 
         or from terminal give command 
         ng g class employee
      


