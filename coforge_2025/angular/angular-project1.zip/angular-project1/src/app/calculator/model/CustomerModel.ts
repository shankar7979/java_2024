export class Customermodel{
    public id:number=0;
    public name:string="";
    public salary:number=0;

    
}