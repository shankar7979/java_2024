export default class Employee{
    public id:number;
    public name:string;
    public salary:number;

    constructor(){
        this.id=989898;
        this.name="suresh kumar";
        this.salary=20000;
    }


}